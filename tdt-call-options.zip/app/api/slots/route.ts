import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { freeSlots } from "@/lib/freeSlots";
import { bookingClosed, parseTier } from "@/lib/slots";
import { liveTier } from "@/lib/pricing";
import { bidFrom } from "@/lib/session";
export const runtime = "nodejs"; export const dynamic = "force-dynamic";

const split = (k?: string) => (k ? { date: k.split("T")[0], time: k.split("T")[1] } : null);

// With the booking cookie: the slot the form will assign to THIS booking.
// With ?tier=standard|urgent: whether a slot of that kind is free right now, and the earliest one — for the landing page.
export async function GET(req: Request) {
  const bid = bidFrom(req);
  if (bid && !new URL(req.url).searchParams.get("tier")) {
    const s = await db.doc(`orders/${bid}`).get(), o = s.data();
    if (!o || o.status !== "paid") return NextResponse.json({ next: null });
    const free = await freeSlots({ tier: o.tier || "standard", paidAt: o.paidAt, bid, prefer: o.heldSlot || undefined });
    return NextResponse.json({ next: split(free[0]) });
  }
  const q = new URL(req.url).searchParams.get("tier"), tier = q ? parseTier(q) : "urgent";
  if ((await liveTier(tier)) !== tier) return NextResponse.json({ available: false, next: null, off: true }); // switched off in /admin
  const closed = bookingClosed(tier); // urgent 3-hour call outside 12 PM – 6 PM IST
  if (closed) return NextResponse.json({ available: false, next: null, closed });
  const free = await freeSlots({ tier });
  return NextResponse.json({ available: free.length > 0, next: split(free[0]) });
}
