import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { db, getCfg } from "@/lib/db";
import { daySlots, slotMs, isTaken, LEAD_MS, HOLD_MS } from "@/lib/slots";
export const runtime = "nodejs"; export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const { date, time, name, email, phone } = await req.json();
  if (!name?.trim() || !/^\S+@\S+\.\S+$/.test(email || "") || (phone || "").replace(/\D/g, "").length < 10)
    return NextResponse.json({ error: "Naam, email aur WhatsApp number sahi bharein." }, { status: 400 });
  const cfg = await getCfg();
  if (!daySlots(cfg, date).includes(time) || slotMs(date, time) < Date.now() + LEAD_MS)
    return NextResponse.json({ error: "Yeh slot available nahi hai." }, { status: 400 });

  const key = `${date}T${time}`, ref = db.doc(`bookings/${key}`), bid = randomUUID().slice(0, 8).toUpperCase();
  const ok = await db.runTransaction(async (tx) => {
    const s = await tx.get(ref);
    if (s.exists && isTaken(s.data())) return false;
    tx.set(ref, { status: "held", holdUntil: Date.now() + HOLD_MS, bid, name: name.trim(), email: email.trim(), phone: phone.trim(), createdAt: Date.now() });
    return true;
  });
  if (!ok) return NextResponse.json({ error: "Yeh slot abhi kisi ne le liya. Doosra slot chunein." }, { status: 409 });

  const auth = Buffer.from(`${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString("base64");
  const r = await fetch("https://api.razorpay.com/v1/payment_links", {
    method: "POST", headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      amount: Number(process.env.PRICE_INR || 8500) * 100, currency: "INR", accept_partial: false,
      reference_id: key, description: `Personal Call Reading — ${date} ${time} IST`,
      customer: { name: name.trim(), email: email.trim(), contact: phone.trim() }, notify: { email: true },
      expire_by: Math.floor(Date.now() / 1000) + 17 * 60, notes: { slot: key, bid },
      callback_url: `${process.env.SITE_URL}/?bid=${bid}`, callback_method: "get",
    }),
  });
  const link = await r.json();
  if (!link.short_url) { await ref.delete(); return NextResponse.json({ error: "Payment link nahi ban paya. Dobara try karein." }, { status: 502 }); }
  await ref.update({ plinkId: link.id });
  return NextResponse.json({ url: link.short_url });
}
