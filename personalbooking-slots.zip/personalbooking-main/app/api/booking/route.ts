import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { formUrl } from "@/lib/calendar";
export const runtime = "nodejs"; export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const bid = new URL(req.url).searchParams.get("bid") || "";
  const q = await db.collection("bookings").where("bid", "==", bid).limit(1).get();
  if (!bid || q.empty) return NextResponse.json({ status: "unknown" });
  const d = q.docs[0].data(), [date, time] = q.docs[0].id.split("T");
  return NextResponse.json({
    status: d.status, date, time, meetLink: d.meetLink || null,
    formUrl: d.status === "confirmed" ? formUrl({ name: d.name, email: d.email, phone: d.phone, bid }) : null,
  });
}
