import { NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import { createMeet } from "@/lib/calendar";
export const runtime = "nodejs"; export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const raw = await req.text();
  const sig = req.headers.get("x-razorpay-signature") || "";
  const good = crypto.createHmac("sha256", process.env.RAZORPAY_WEBHOOK_SECRET as string).update(raw).digest("hex");
  if (sig.length !== good.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good)))
    return NextResponse.json({ error: "bad signature" }, { status: 401 });

  const ev = JSON.parse(raw);
  if (ev.event !== "payment_link.paid") return NextResponse.json({ ok: true });
  const pl = ev.payload.payment_link.entity, key = pl.reference_id as string, ref = db.doc(`bookings/${key}`);

  const b = await db.runTransaction(async (tx) => {
    const s = await tx.get(ref), d = s.data();
    if (!d || d.plinkId !== pl.id) { tx.set(db.doc(`problems/${pl.id}`), { key, paymentLink: pl.id, why: "paid but slot missing/mismatch — refund manually", at: Date.now() }); return null; }
    if (d.status === "confirmed") return null; // webhook retry
    tx.update(ref, { status: "confirmed", paymentId: ev.payload.payment?.entity?.id || null, paidAt: Date.now() });
    return d;
  });
  if (b) {
    const m = await createMeet(key, b as any).catch((e) => { console.error("calendar failed", e); return null; });
    await ref.update({ meetLink: m?.meetLink || null, eventId: m?.eventId || null, calendarOk: !!m?.meetLink });
  }
  return NextResponse.json({ ok: true });
}
