"use client";
import { useEffect, useState } from "react";
const fmtD = (d: string) => new Date(d + "T00:00:00Z").toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short", timeZone: "UTC" });
const fmtT = (t: string) => { const [h, m] = t.split(":").map(Number); return `${h % 12 || 12}:${String(m).padStart(2, "0")} ${h < 12 ? "AM" : "PM"}`; };
const chip = (on: boolean) => ({ padding: "8px 12px", borderRadius: 8, cursor: "pointer", border: "1px solid #c9a227", background: on ? "#c9a227" : "transparent", color: on ? "#111" : "inherit" }) as const;
const inp = { width: "100%", padding: 10, borderRadius: 8, border: "1px solid #777", background: "transparent", color: "inherit", marginTop: 8 } as const;

export default function BookingWidget({ price }: { price: string }) {
  const [slots, setSlots] = useState<Record<string, string[]> | null>(null);
  const [date, setDate] = useState(""), [time, setTime] = useState("");
  const [f, setF] = useState({ name: "", email: "", phone: "" }), [err, setErr] = useState(""), [busy, setBusy] = useState(false);
  const [paid, setPaid] = useState<any>(null), [bid, setBid] = useState("");

  useEffect(() => {
    const b = new URLSearchParams(window.location.search).get("bid");
    if (b) { setBid(b); return; }
    fetch("/api/slots").then((r) => r.json()).then((j) => setSlots(j.slots)).catch(() => setSlots({}));
  }, []);
  useEffect(() => { // after payment: wait for webhook to confirm
    if (!bid) return;
    let n = 0; const t = setInterval(async () => {
      const j = await (await fetch(`/api/booking?bid=${bid}`)).json(); setPaid(j);
      if (j.status === "confirmed" || ++n > 40) clearInterval(t);
    }, 3000); return () => clearInterval(t);
  }, [bid]);

  async function pay() {
    setErr(""); setBusy(true);
    const r = await fetch("/api/book", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ date, time, ...f }) });
    const j = await r.json(); setBusy(false);
    if (j.url) window.location.href = j.url; else { setErr(j.error || "Kuch galat hua"); if (r.status === 409) location.reload(); }
  }

  if (bid) return (
    <div>
      {paid?.status === "confirmed" ? (<>
        <b>✓ Booking confirmed — {fmtD(paid.date)}, {fmtT(paid.time)} (IST)</b>
        <p style={{ fontSize: 14 }}>Google Meet link aur invite aapki email pe bhej diya gaya hai{paid.meetLink ? <>: <a href={paid.meetLink}>{paid.meetLink}</a></> : ""}.</p>
        <a href={paid.formUrl} target="_blank" rel="noopener noreferrer" className="btn gold" style={{ width: "100%", justifyContent: "center" }}>Ab Personal Reading Form bharein (zaroori)</a>
      </>) : <p>Payment confirm ho raha hai… kripya page band na karein.</p>}
    </div>);

  if (!slots) return <p>Slots load ho rahe hain…</p>;
  const dates = Object.keys(slots);
  if (!dates.length) return <p>Abhi koi slot khaali nahi hai. Kuch din baad dobara dekhein.</p>;
  const ready = date && time && f.name && f.email && f.phone;
  return (
    <div>
      <div style={{ fontWeight: 600 }}>1. Din chunein</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8, margin: "8px 0 14px" }}>
        {dates.map((d) => <button key={d} style={chip(d === date)} onClick={() => { setDate(d); setTime(""); }}>{fmtD(d)}</button>)}
      </div>
      {date && (<>
        <div style={{ fontWeight: 600 }}>2. Time chunein (India Time)</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, margin: "8px 0 14px" }}>
          {slots[date].map((t) => <button key={t} style={chip(t === time)} onClick={() => setTime(t)}>{fmtT(t)}</button>)}
        </div></>)}
      <input style={inp} placeholder="Poora naam" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
      <input style={inp} type="email" placeholder="Email (isi pe Meet link aayega)" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
      <input style={inp} type="tel" placeholder="WhatsApp number" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
      {err && <p style={{ color: "#f66" }}>{err}</p>}
      <button className="btn gold" disabled={!ready || busy} onClick={pay} style={{ width: "100%", justifyContent: "center", marginTop: 14, opacity: ready ? 1 : 0.5 }}>
        {busy ? "Slot hold ho raha hai…" : `Slot book karke ${price} pay karein`}
      </button>
    </div>);
}
